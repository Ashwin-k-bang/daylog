# Daylog (v5) + Revise

Upload everything in this zip to the repo root (index.html, daylog.html, category.html, money.html, sync.js, sw.js, icon-*.png and the Revise/ folder).
The data/ folder holds your logs as of the day this zip was made (daylog.json, money.json). Upload it only if you deleted data/ from the repo; otherwise skip it so newer logs are not overwritten. data/revise.json is created by the app itself.

Daylog:  https://<user>.github.io/<repo>/
Revise:  https://<user>.github.io/<repo>/Revise/   (capital R)

Each device needs the GitHub token once: tap "Sync" and paste it, or open https://<user>.github.io/<repo>/#token=YOUR_TOKEN once on that device.
